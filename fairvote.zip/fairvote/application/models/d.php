<?php
class M_login extends CI_Model{
    
    public function validateSignin($userName, $password){
        return $this->db->get_where('user', array('username'=>$userName, 'password'=>$password));
    }

    public function validateSignup($data){
        return $this->db->get_where('user', $data);
    }

}
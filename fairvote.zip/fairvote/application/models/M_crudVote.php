<?php
class M_crudVote extends CI_Model{
    
    public function createVote($dataVote){
		  return $this->db->insert('vote', $dataVote);
    }

    public function createOption($randomCode, $option, $desc){
		  return $this->db->query('call crate_option("'.$this->db->escape_str($randomCode).'", "'.$this->db->escape_str($option).'", "'.$this->db->escape_str($desc).'")');
    }

    public function readVoteByCode($code){
        return $this->db->get_where('vote', array('share_code' => $code));
    }

    public function readOption($code){
        return $this->db->get_where('option', array('share_code_option' => $code));
    }
    
    public function updateOptionVoteCount($code, $option){
        return $this->db->query('call update_option_vote_count("'.$this->db->escape_str($code).'", "'.$this->db->escape_str($option).'")');
    }

    public function readHistory($name, $code){
        return $this->db->get_where('history', array('username_history'=>$name, 'share_code_history'=>$code));
    }

    public function createHistory($dataHisitory){
        return $this->db->insert('history', $dataHisitory);
    }
}
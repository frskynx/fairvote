<?php
class M_crudUser extends CI_Model{
    
    public function validateSignin($userName, $password){
        return $this->db->get_where('user', array('username'=>$userName, 'password'=>$password));
    }

    public function validateSignup($username){
        return $this->db->get_where('user', array('username' => $username));
    }

    public function createUser($username, $password){
        return $this->db->insert('user', array('username'=>$username, 'password'=>$password));
    }

}
<?php
class Auth extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('M_crudUser');
    }

    public function signinAction()
    {   
        $username = $this->input->post('userName');
        $password = $this->input->post('password');

        $validate = $this->M_crudUser->validateSignin($username, $password)->num_rows();
        if ($validate > 0) {
            $data_session = array(
                'logged' => TRUE,
                'username' => $username
            );
            $this->session->set_userdata($data_session);
            redirect('nav/index/'.$_SESSION['logged']);
        } else if ($username == '' || $password =='') {
            echo $this->session->set_flashdata('msg', '<div class="mb-3 alert alert-danger text-center p-2">Make sure name and password is not empty</div>');
            redirect('nav#signin');
        } else {
            echo $this->session->set_flashdata('msg', '<div class="mb-3 alert alert-danger text-center p-2">Something Wrong</div>');
            redirect('nav#signin');
        }
    }


    public function signout()
    {
        $this->session->sess_destroy();
        redirect('nav');

    }
}
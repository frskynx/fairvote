<?php
class Vote_crud extends CI_Controller {
    function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('M_crudVote');
    }

    function generateRandomCode() { 
        $chars = "abcdefghijkmnopqrstuvwxyz0123456789ABCDEFGHAIJKLMNOPQRSTUVWXYZ"; 
        srand((double)microtime()*1000000); 
        $i = 0; 
        $pass = '' ; 
    
        while ($i <= 5) { 
            $num = rand() % 33; 
            $tmp = substr($chars, $num, 1); 
            $pass = $pass . $tmp; 
            $i++; 
        } 
        return $pass; 
    }

    public function create(){
        $voteName = $this->input->post('voteName');
        $optionCount = $this->input->post('optionCount');
        $randomCode = $this->generateRandomCode();

        $data = array(
            'randomCode' => $randomCode,
            'voteName' => $voteName,
            'optionCount' => $optionCount
        );
        
        $this->load->view('layout/header');	
        $this->load->view('crud/create', $data);
        $this->load->view('layout/footer');	
    }
    
    public function createAction() {
        $randomCode = $this->input->post('randomCode');
        $voteName = $this->input->post('voteName');
        $optionCount = $this->input->post('optionCount');
        $userName = $_SESSION['username'];

        $dataVote = array(
            'user_name_vote' => $userName,
            'vote_name' => $voteName,
            'share_code' => $randomCode,
            'option_count' => $optionCount
        );
        $this->M_crudVote->createVote($dataVote);

        for($i = 0; $i < $optionCount; $i++){
            $option = $this->input->post('option'.$i);
            $desc = $this->input->post('desc'.$i);

            $dataOption = array (
                'sharing_code_option' => $randomCode,
                'option' => $option,
                'description' => $desc
            );
            $this->M_crudVote->createOption($randomCode, $option, $desc);
        }
        redirect('nav/index/'.$_SESSION['logged']);
    }

    public function readOption(){
        $code = $this->input->post('code');

        $result = $this->M_crudVote->readHistory($_SESSION['username'], $code)->num_rows();
        if ($result > 0) { //Tidak ditemukan
            redirect('nav/index/'.$_SESSION['logged'].'#vooting');
        } else {
            $data['vote'] = $this->M_crudVote->readVoteByCode($code)->result_array();
            $data['option'] = $this->M_crudVote->readOption($code)->result_array();
    
            $this->load->view('layout/header');	
            $this->load->view('crud/readOption', $data);
            $this->load->view('layout/footer');	         
        }
    }

    public function updateVoting(){
        $code = $this->input->post('code');
        $option = $this->input->post('option');
        $this->M_crudVote->updateOptionVoteCount($code, $option);

        $dataHistory = array (
            'username_history' => $_SESSION['username'],
            'share_code_history' => $code,
            'status' => 1
        );
        $this->M_crudVote->createHistory($dataHistory);

        redirect('nav/index/'.$_SESSION['logged']);
    }
}
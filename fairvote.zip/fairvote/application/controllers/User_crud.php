<?php
class User_crud extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('M_crudUser');
    }

    public function createUser()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        if ($username == '' || $password == ''){
            echo $this->session->set_flashdata('msg', '<div class="mb-3 alert alert-danger text-center p-2">Make sure name and password is not empty</div>');
            redirect('nav#signup');
        };

        $validate = $this->M_crudUser->validateSignup($username)->num_rows();
        if ($validate > 0){
            echo $this->session->set_flashdata('msg', '<div class="mb-3 alert alert-danger text-center p-2">User name has been used</div>');
            redirect('nav#signup');
        } else {
            $this->M_crudUser->createUser($username, $password);
            redirect('nav#signup-succes', $username);
        }

    }
}
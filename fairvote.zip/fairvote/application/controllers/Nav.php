<?php
class Nav extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->library('session');
    }

	public function index($logged = FALSE)
    {   
        $data_session = array(
            'logged' => $logged
        );
        $this->session->set_userdata($data_session);
        $this->load->view('layout/header');	
        $this->load->view('home');	
        $this->load->view('overlay/sign_overlay');	
        $this->load->view('layout/footer');	
    }

    public function dashboard() {
        $data['vote'] = $this->db->get_where('vote', array('user_name_vote' => $_SESSION['username']))->result_array();
        $i = 0;
        foreach ($data['vote'] as $row){
            $data['option'.$i] = $this->db->get_where('option', array('share_code_option' => $row['share_code']))->result_array();
            $i++;
        };

        $this->load->view('layout/header');
        $this->load->view('dashboard', $data);	
        $this->load->view('layout/footer');	
    }

    public function about() {
        $this->load->view('layout/header');	
        $this->load->view('maintenance');	
        $this->load->view('overlay/sign_overlay');	
        $this->load->view('layout/footer');	
    }

    public function suport() {
        $this->load->view('layout/header');	
        $this->load->view('maintenance');	
        $this->load->view('overlay/sign_overlay');	
        $this->load->view('layout/footer');	
    }
}
    <link rel="stylesheet" href="<?php echo base_url('assets/css/home.css'); ?>">
    <?php
      $logged = $_SESSION['logged'];
    ?>
    
    <div class="container text-center p-4">
      <div class="row">
        <div class="col-lg-6 p-4">
          <img class="img-fluid" src="<?php echo base_url('assets/img/hero-ilustration.png'); ?>" alt="hero">
        </div>
        <div class="col-lg-3 m-auto">
            <a href="
            <?php 
              if($logged == TRUE){
                echo "#vooting";
              } else {
                echo "#signin";
              };
            ?>
            "><p class="mb-3 m-auto btn btn-lg btn-primary d-grid home-btn">Start Vote</p></a>
            <a href="
              <?php 
                if($logged == TRUE){
                  echo "#making";
                } else {
                  echo "#signin";
                };
              ?>
            "><p class="m-auto btn btn-lg btn-primary d-grid home-btn">Make Vote</p></a>
        </div>
      </div>
    </div>
    
    <div class="floating" id="vooting">
      <div class="m-auto p-4" id="card">
        <h3 class="mb-3 fw-normal text-center">Share code</h3>
        <form action="<?=site_url('vote_crud/readOption');?>" method="POST">
          <div class="row mb-3">
            <div class="col">
              <input type="text" class="form-control" placeholder="Paste here" name='code' value='dapxyp' require>
            </div>
          </div>
          <div class="row">
            <div class="col m-auto">
              <button type="submit" class="btn btn-primary">Vote</button>
              <a href="#" class="btn btn-danger">Cencel</a>
            </div>
          </div>
        </form>
      </div>
    </div>

    <div class="floating" id="making">
      <div class="m-auto p-4" id="card">
        <h3 class="mb-3 fw-normal">Make vote</h3>
        <form action="<?=site_url('vote_crud/create');?>" method="POST">
          <div class="row g-3 mb-3">
            <div class="col-md-9">
              <input type="text" class="form-control" placeholder="Vote name" name='voteName' require>
            </div>
            <div class="col-md-3">
              <input type="number" class="form-control" placeholder="Option" aria-label="Option" name='optionCount'>
            </div>
          </div>
          <div class="row">
            <div class="col m-auto">
              <button type="submit" class="btn btn-primary">Make</button>
              <a href="#" class="btn btn-danger">Cencel</a>
            </div>
          </div>
        </form>
      </div>
    </div>

    <div class="floating" id="signup-succes">
        <span class="m-auto p-4" id="card">
          <p class="text">Hi <?php echo $username; ?>,your account has been successfully registered <a href="#signin">click here</a> to sign in</p>
        </span>
    </div>
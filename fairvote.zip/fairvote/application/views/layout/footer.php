    <div class="container fixed-bottom">
        <footer class="d-flex flex-wrap justify-content-between align-items-center my-4">
            <p class="col-md-12 mb-0 text-body-secondary">&copy; 2023 Frskyxvwxzvxwsyvx, Inc</p>
            </ul>
        </footer>
    </div>
    <script type="text/javascript" src="<?php echo base_url("assets/js/bootstrap.bundle.min.js"); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url("assets/js/my.script.js"); ?>"></script>
  </body>
</html>
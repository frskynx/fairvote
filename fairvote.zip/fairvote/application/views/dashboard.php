<link rel="stylesheet" href="<?php echo base_url('assets/css/dashboard.css'); ?>">

<div class="container">
    <div class="mt-5 mb-5">
        <img src="<?=base_url('assets/img/profile/admin.jpg')?>" alt="profile" class="rounded-circle float-start me-3" width="80px">
            <h1 class="text-capitalize"><?= $_SESSION['username']?></h1>
            <p>Nek kulo mboten pripun pripun mboten mboten pripun</p>
    </div>

    <div class="content row">
        <div class="col col-lg-6">
            <h4 class="m-3">My vote</h4>
            <?php $i = 0; foreach ($vote as $row) {?>
            <div class="list-group">
                <a class="text-dark text-decoration-none list-group-item list-group-item-action" data-bs-toggle="collapse" href="#collapse<?=$i;?>" role="button" aria-expanded="false" aria-controls="collapse1" aria-current="true">
                    <div class=d-flex>
                        <p class="mb-0"><?=$row['vote_name'];?></p><p class="mb-0"> - <?=$row['voting_count'];?> vote</p>
                    </div>
                    <?php foreach(${'option'.$i} as $col) { ?>
                        <div class="collapse multi-collapse list-group-item-action" id="collapse<?=$i;?>">
                            <?=$col['option'].' - '.$col['description'];?> 
                        </div>
                    <?php } ?>
                        <div class="collapse multi-collapse list-group-item-action" id="collapse<?=$i;?>">
                            <span><a class="text-decoration-none text-primary" href="#edit">Edit</a> <a class="text-decoration-none text-danger" href="#del">Delete</a></span>
                        </div>
                 </a>
            </div>
            <?php $i++; } ?>
        </div>
        <div class="col col-lg-3">
            <h4 class="m-3">History</h4>
        </div>
    </div>
</div>
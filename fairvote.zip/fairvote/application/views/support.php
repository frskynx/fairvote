<link rel="stylesheet" href="<?php echo base_url('assets/css/home.css'); ?>">
<style>
a {
	text-decoration: none;
    color: black;
}
</style>

<div class="container text-center" style="max-width : 400px; margin-top : 2.3%">
    <a class="content" href="https://saweria.co/frskynx" target="_blank">
        <img class="img-fluid mb-5" src="<?php echo base_url('assets/img/support-ilustration.png'); ?>" alt="EROR 404">
        <h4 class="h4">Hi there👋</h4>
        <p>I just start created a page, just buy me a cup off coffe!</p>
    </a>
</div>
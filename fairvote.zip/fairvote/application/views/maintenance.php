<link rel="stylesheet" href="<?php echo base_url('assets/css/home.css'); ?>">

<div class="container text-center" style="max-width : 550px; margin-top : 7.5%">
    <div class="content">
        <img class="img-fluid" src="<?php echo base_url('assets/img/maintenance-ilustration.png'); ?>" alt="EROR 404">
        <h4 class="h4">Page under maintenance</h4>
        <p>We are currently updating our service and adding some cool new features.<br>We will be back shortly. Thank you for your patience </p>
    </div>
</div>
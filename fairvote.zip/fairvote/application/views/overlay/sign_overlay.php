<div class="floating" id="signin">
      <div class="p-5" id="card">
        <div class="text-center mb-5">
            <img src="<?php echo base_url('assets/img/icon.png'); ?>" alt="Logo" height="32" class="mb-3">
            <h4 class="h4 fw-normal">Please sign in</h4>
        </div>        
        <form action="<?=site_url('auth/signinAction');?>" method="POST">
          <div class="row mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="userName" value="admin">
          </div>
          <div class="row mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" value="admin">
          </div>
          <div class="text-center">

            <?php echo $this->session->flashdata('msg'); ?>

            <span><p class="text"><a href="#signup">Sign up</a> if you dont have any acount</p></span>
            <button type="submit" class="btn btn-primary">Sign in</button>
            <a href="#" class="btn btn-danger">Cencel</a>
          </div>
        </form>
      </div>
    </div>

    <div class="floating" id="signup">
      <div class="p-5" id="card">
        <div class="text-center mb-2">
            <img src="<?php echo base_url('assets/img/icon.png'); ?>" alt="Logo" height="32" class="mb-3">
            <h4 class="h4 fw-normal">Vairvote Sign up</h4>
        </div>
        <form action="<?=site_url('user_crud/createUser');?>" method="POST">
          <div class="row mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" id="username" name="username" value="admin">
          </div>
          <div class="row mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" value="admin">
          </div>
          <div class="row mb-3">
            <label for="email" class="form-label">E-mail</label>
            <input type="email" class="form-control" id="email" name="email" value="admin@gmail.com">
          </div>

          <div class="text-center">

            <?php echo $this->session->flashdata('msg'); ?>
            
            <span><p class="text"><a href="#signin">Sign in</a> if you already have an acount</p></span>
            <button type="submit" class="btn btn-primary">Sing up</button>
            <a href="#" class="btn btn-danger">Cencel</a>
          </div>
        </form>
      </div>
    </div>


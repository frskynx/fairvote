<div class="container">
    <div class="text-center m-5">
        <h1 class="h1"><?=$voteName;?></h1>
        <p>Nek kulo kula mboten pripun pripun mboten mboten pripun kula pripun nggih mpun</p>
    </div>
    <form action="createAction" method='POST'>
        
            <div class="row text-center">
                <div class="col-4">
                    <label for="option" class="form-label">Option</label>
                </div>
                <div class="col-8">
                    <label for="desc" class="form-label">Description</label>
                </div>
            </div>
            <?php for($i = 0 ; $i < $optionCount ; $i++ ){
                echo'
                    <div class="row mb-2">
                        <div class="col-4">
                            <input type="text" class="form-control" placeholder="Option '; echo $i + 1; echo '" name="option'; echo $i; echo '">
                        </div>
                        <div class="col-8">
                            <input type="text" class="form-control" rows="2" name="desc'; echo $i; echo '">
                        </div>
                    </div>
                ';
                };
            ?>
            <input type="text" name="optionCount" value="<?=$optionCount;?>" hidden>
            <input type="text" name="randomCode" value="<?=$randomCode;?>" hidden>
            <input type="text" name="voteName" value="<?=$voteName;?>" hidden>
            <div class="text-center mt-4">
                <button type="submit" class="btn btn-success">Create</button>
            </div>
    </form>
</div>
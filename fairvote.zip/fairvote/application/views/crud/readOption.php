<link rel="stylesheet" href="<?php echo base_url('assets/css/readOptiona.css'); ?>">

<div class="container">
    <div class="text-center m-5">
    <?php foreach ($vote as $row) { ?>
            <h1 class="h1"><?php echo $row['vote_name']; ?></h1>
    <?php } ?>
            <p>Nek kulo kula mboten pripun pripun mboten mboten pripun kula pripun nggih mpun</p>
    </div>
    <?php $i = 0; foreach ($option as $row) { ?>
        <a class="content text-decoration-none" href="#validate<?=$i?>">
            <div class="option text-decoration-none">
                <div class="text text-decoration-none ">
                    <h3><?php echo $row['option']; ?></h3>
                    <p><?php echo $row['description']; ?></p>
                </div>
            </div>
        </a>

        <div class="floating validate" id="validate<?=$i?>">
          <div class="m-auto p-4" id="card">
            <h3 class="mb-3 fw-normal text-center">Are you sure?</h3>
            <form action="<?=site_url('vote_crud/updateVoting');?>" method="POST">
              <div class="row">
                <div class="col m-auto">
                  <input type="text" name="option" value="<?=$row['option']; ?>" hidden>
                  <input type="text" name="code" value="<?=$row['share_code_option']; ?>" hidden>
                  <button type="submit" class="btn btn-primary">Vote</button>
                  <a href="#" class="btn btn-danger">Cencel</a>
                </div>
              </div>
            </form>
          </div>
        </div>
    <?php $i++; } ?>

</div>
